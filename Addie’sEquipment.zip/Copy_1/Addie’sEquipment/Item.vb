﻿Public Class Item
    'properties from ItemDetails
    Public EquipmentType As String
    Public DailyRate As String
    Public DaysRate As String
End Class